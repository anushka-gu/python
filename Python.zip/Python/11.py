my_string ="Bharati"

#alternative method to print the reverse - print(my_string[::-1])

reversed_string =""
for char in my_string:
 reversed_string =  char + reversed_string
print("ORIGINAL STRING",my_string)
print("REVERSED STRING",reversed_string)

# numbers = [1,2,3,4,5]
# print(type(numbers))

# coordinates = (10.0,20.0)
# print(type(coordinates))

# person = {"NAME": "Alice", "AGE":25}
# print(type(person))

# unique_numbers ={11,12,13,14,15}
# print(type(unique_numbers))


# print(numbers)
# print(coordinates)
# print(person)
# print(unique_numbers)

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")