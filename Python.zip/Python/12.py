#DEFINE
a=15
b=4
#BASIC ARITHMETIC OPERTATIONS
sum_result=a+b
difference=a-b
product=a*b
quotient=a/b
#FLOOR DIVISION AND MODULUS
floor_div=a//b
reminder=a%b
#EXPONENTATION
power=a**b
#DISPLAY RESULTS
print(f"sum: {sum_result}")
print(f"difference: {difference}")
print(f"product: {product}")
print(f"quotient: {quotient}")
print(f"floor_div: {floor_div}")
print(f"reminder: {reminder}")
print(f"power: {power}")
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")
