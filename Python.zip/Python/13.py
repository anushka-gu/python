#Python program to demonstate Basic Math Functions
# Absolute value of a negative number
absolute_value =  abs(-7) #7
#rounding a number to a two decimal places
rounded_value = round(3.14159 , 2) #3.14
#Calculating power
power_value = pow(2,3) #8

print(f"absolute value : {absolute_value}")
print(f"rounded value: {rounded_value}")
print(f"power value : {power_value}")
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")