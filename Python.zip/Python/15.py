a = 10
print(f"a = {a}")
a += 15
print(f"a +=  15 -> {a}")

a-= 15
print(f"a -= 15 -> {a}")

a *= 15
print(f"a *= 15 -> {a}")

a /= 15
print(f"a /= 15 -> {a}")

a %= 15
print(f"a %= 15 -> {a}")

a //= 15
print(f"a //= 15 -> {a}")

a **= 15
print(f"a **= 15 -> {a}")

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")