a = int(input("Enter the value of a: "))
b  = int(input("Enter the value of b: "))

#equal to
print(f"{a} == {b} : {a == b}")
#not equal to
print(f"{a} != {b} : {a != b}")
#Greater than
print(f"{a} > {b} : {a > b}")
#less than
print(f"{a} < {b} : {a < b}")
#Greater than or equal to
print(f"{a} >= {b} : {a >= b}")
#Less than or equal to
print(f"{a} <= {b} : {a <= b}")

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")