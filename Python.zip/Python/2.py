variable = 10
_variable = "underscore"
var123 = 3.14
print(variable)
print(_variable)
print(var123)

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")