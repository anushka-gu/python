var1 = 'a' in 'abcd'  # True since 'a' is part of string "abcd"
print(var1)

var2 = 5 in [7, 6, 5, 4]  # True since 5 is in the list
print(var2)

var3 = 4 in [9, 0, 7, 8]  # False since 4 is not in the list 
print(var3)

var4 = 'apple' in {'a': 'apple', 'b': 'boy', 'c': 'cat'} 
print(var4)

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")