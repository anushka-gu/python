# Python program to demonstrate formatted or F string

name = "Jagrit"
age = 19
print(f"Name: {name} , Age: {age}")
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")