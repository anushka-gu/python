#math module
import math

num = 16
print(f"Square root of {num} is {math.sqrt(num)}")
print(f"Factorial of {num} is {math.factorial(num)}")
print(f"Logarithm of {num} is {math.log2(num)}")

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")