# Example of a while loop in Python
count = 0
while count < 5:
    print("Count is:", count)
    count += 1  

    print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")