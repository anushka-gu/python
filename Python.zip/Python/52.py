# Program to Use Iterators in a Loop:

my_list = [1, 2, 3, 4]
it = iter(my_list)
for item in it:
 print(item) # Outputs: 1, 2, 3, 4
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")