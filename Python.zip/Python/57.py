# Program to Use Set Comprehension:

squares = {x**2 for x in range(5)}
print(squares) # Outputs: {0, 1, 4, 9, 16}
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")