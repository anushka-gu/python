# Python Program demonstrate various data type
# Numbers
integer = 42
floating_point = 3.2
complex_num= 1+2j

#printing out
print("Integer:" +str(integer))
print("Floating_point:"+str(floating_point))
print("Complex_num:"+str(complex_num))

#Boolean
testbool= True
print("Boolean",testbool)
#sequence
string = "Hello world"
tuple_seq =(1,2,3)
list_seq = [1,2,3]

print("String",string)
print("Turple_seq",tuple_seq)
print("List_seq",list_seq)

#sets
set_type={1,2,3}
print("Set_type",set_type)

#Mapping
dictionary = {"key":"value"}
print("dictionary",dictionary)

#none
none_type =""
print("None", none_type)

print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")