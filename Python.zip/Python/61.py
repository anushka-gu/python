# Program to Use range() with Step:

for i in range(1, 10, 2):
 print(i) # Outputs: 1, 3, 5, 7, 9
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")