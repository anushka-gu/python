# Program to Use range() for Iteration:

for i in range(5):
 print(i) # Outputs: 0, 1, 2, 3, 4
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")