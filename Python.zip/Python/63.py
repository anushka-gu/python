# Program to Use range() with Start and Stop:

for i in range(2, 6):
 print(i) # Outputs: 2, 3, 4, 5
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")