# Program to Create and Access Tuples:

my_tuple = (1, 2, 3, 4)
print(my_tuple[0]) # Outputs: 1
print(my_tuple[-1]) # Outputs: 4
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")