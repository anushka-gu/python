# Program to Create and Access Nested Tuples:

nested_tuple = (1, (2, 3), 4)
print(nested_tuple[1][0]) # Outputs: 2
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")