# Program to Access and Remove Dictionary Elements:

my_dict = {'name': 'Bob', 'age': 30, 'job': 'Engineer'}
name = my_dict.get('name')
my_dict.pop('job')
print(name) # Outputs: Bob
print(my_dict) # Outputs: {'name': 'Bob', 'age': 30}
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")