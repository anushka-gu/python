#WAP to create a default function 
def greet(name="guest"):
    print(f"Hello,{name}!")
greet()
greet("Jagrit")
print("This code is written by Jagrit Ahuja ERP- 0221BCA142")