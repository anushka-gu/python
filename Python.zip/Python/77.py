# Write a Python program to demonstrate No explicit return

def greet(name):
    print(f"Hello,{name}")
result = greet("Jagrit")
print(result)
print("77. This code is written by Jagrit Ahuja ERP- 0221BCA142")