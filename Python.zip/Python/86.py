# WAP for importing all function

from math_utils import * 
result = subtract(10, 8) 
print(result)
print("86. This code is written by Jagrit Ahuja ERP- 0221BCA142")
