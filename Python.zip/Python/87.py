# WAP to demonstrate aliasing module and functions

import math_utils as mu 
result = mu.add(5, 45) 
print(result)
print("87. This code is written by Jagrit Ahuja ERP- 0221BCA142")
